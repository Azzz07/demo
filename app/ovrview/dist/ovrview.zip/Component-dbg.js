sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("ovrview.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);